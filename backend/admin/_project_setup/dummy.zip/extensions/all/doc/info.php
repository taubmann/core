<?php
$info = <<<EOD
{
	"info":  {
		"name": "all",
		"description": "basic stuff for cms-kit",
		"authors":  [
			"Christoph Taubmann"
		],
		"homepage": "http://cms-kit.org",
		"mail": "info@cms-kit.org",
		"copyright": "GPL"
	},
	"system":  {
		"version": 0.6,
		"install_to": "project",
		"translations":  [
			"en",
			"de"
		]
	}

}
EOD;
