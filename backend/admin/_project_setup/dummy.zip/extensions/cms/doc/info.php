<?php
$info = <<<EOD
{
	"info":  {
		"name": "cms",
		"description": "basic Hooks for the Project",
		"authors":  [
			"Christoph Taubmann"
		],
		"homepage": "http://cms-kit.org",
		"mail": "info@cms-kit.org",
		"copyright": "GPL"
	},
	"system":  {
		"version": 0.5,
		"install_to": "project",
		"translations":  [
			"en",
			"de"
		]
	}

}
EOD;
