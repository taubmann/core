<?php
// empty cms-kit XML-Data-Model
$model = <<<EOD
<?xml version="1.0" encoding="utf-8" ?>
<objects>
	<object />
</objects>
EOD;
?>
