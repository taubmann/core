# Information about the Files

JSON in Backup-Files is stored as php with a exit-command at the Beginning.

## Format

Filenames have the following Structure (Uppercase-Strings are Placeholders)

Models

	0-MODELNAME-TIMESTAMP.php

Entries (from Database)

	OBJECTNAME-FIELDNAME-ID-TIMESTAMP.php


