<?php
$info = <<<EOD
{
	"info":  {
		"name": "",
		"description": "",
		"authors":  [
			""
		],
		"homepage": "",
		"mail": "",
		"copyright": "GPL"
	},
	"system":  {
		"version": 0,
		"install_to": "project",
		"requirements":  {
		},
		"dependencies":  {
		},
		"tables":  [
		],
		"hooks" : {
		},
		"translations":  [
			"en"
		]
	}
}
EOD;
